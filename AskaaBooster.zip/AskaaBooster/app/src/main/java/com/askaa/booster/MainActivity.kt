package com.askaa.booster

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.askaa.booster.databinding.ActivityMainBinding
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val main = Handler(Looper.getMainLooper())
    private var unlocked = false
    private var notifAsked = false
    private var pendingLaunch: String? = null

    private val refresher = object : Runnable {
        override fun run() {
            refreshStatus()
            main.postDelayed(this, 2000L)
        }
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startBooster() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Notifier.createChannels(this)

        binding.btnUnlock.setOnClickListener { authenticate() }
        binding.btnUsage.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        binding.btnDnd.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        binding.btnWrite.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        binding.btnStart.setOnClickListener { startBooster() }
        binding.btnStop.setOnClickListener { stopBooster() }
        binding.btnPick.setOnClickListener {
            startActivity(Intent(this, PickGameActivity::class.java))
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        if (!unlocked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        unlocked = false
    }

    override fun onResume() {
        super.onResume()
        renderGames()
        main.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(refresher)
    }

    /** Kunci app: sidik jari atau kunci layar HP. Kalau HP belum punya kunci, app langsung terbuka. */
    private fun authenticate() {
        if (!Prefs.isOn(this, Option.LOCK) || !Device.isDeviceSecure(this)) {
            showContent()
            return
        }

        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                showContent()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                showLock()
            }
        }

        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), callback)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Buka Askaa Booster")
            .setSubtitle("Pakai sidik jari atau kunci layar HP kamu")

        if (Build.VERSION.SDK_INT >= 30) {
            info.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
        } else {
            info.setDeviceCredentialAllowed(true)
        }
        prompt.authenticate(info.build())
    }

    private fun showContent() {
        unlocked = true
        binding.lockView.visibility = View.GONE
        binding.content.visibility = View.VISIBLE
    }

    private fun showLock() {
        unlocked = false
        binding.content.visibility = View.GONE
        binding.lockView.visibility = View.VISIBLE
    }

    private fun startBooster(launch: String? = null) {
        if (!Device.hasUsageAccess(this)) {
            toast("Izinkan pemakaian data dulu, lalu kembali ke sini")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !notifAsked &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifAsked = true
            pendingLaunch = launch ?: pendingLaunch
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }

        ContextCompat.startForegroundService(this, Intent(this, BoostService::class.java))

        val target = launch ?: pendingLaunch
        pendingLaunch = null
        val gameIntent = target?.let { packageManager.getLaunchIntentForPackage(it) }
        if (gameIntent != null) {
            startActivity(gameIntent)
        } else {
            toast("Booster aktif. Silakan buka game kamu.")
        }
    }

    private fun stopBooster() {
        stopService(Intent(this, BoostService::class.java))
        toast("Booster dimatikan. Setting dikembalikan.")
        main.postDelayed({ refreshStatus() }, 1000L)
    }

    private fun renderGames() {
        binding.gameList.removeAllViews()
        val installed = Prefs.games(this)
            .filter { Device.isInstalled(this, it) }
            .map { it to Device.labelOf(this, it) }
            .sortedBy { it.second.lowercase() }

        binding.gameEmpty.visibility = if (installed.isEmpty()) View.VISIBLE else View.GONE
        installed.forEach { (pkg, label) ->
            val row = layoutInflater.inflate(R.layout.item_game, binding.gameList, false)
            row.findViewById<TextView>(R.id.gameName).text = label
            row.findViewById<MaterialButton>(R.id.gamePlay).setOnClickListener { startBooster(pkg) }
            binding.gameList.addView(row)
        }
    }

    private fun refreshStatus() {
        binding.usageValue.text = yesNo(Device.hasUsageAccess(this))
        binding.dndValue.text = yesNo(Device.hasDndAccess(this))
        binding.writeValue.text = yesNo(Device.canWriteSettings(this))
        binding.tempValue.text = String.format("%.1f °C", Device.batteryTempC(this))
        binding.boostValue.text = if (Prefs.isBoosted(this)) "aktif" else "tidak aktif"
        binding.statusValue.text = Prefs.status(this)
    }

    private fun yesNo(ok: Boolean): String = if (ok) "sudah diizinkan" else "belum diizinkan"

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
