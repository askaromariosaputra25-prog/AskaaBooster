package com.askaa.booster

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.askaa.booster.databinding.FragmentGamesBinding
import com.google.android.material.button.MaterialButton

class GamesFragment : Fragment() {

    private var _b: FragmentGamesBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentGamesBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.btnPick.setOnClickListener {
            startActivity(Intent(requireContext(), PickGameActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        renderGames()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private fun renderGames() {
        val ctx = context ?: return
        b.gameList.removeAllViews()
        val installed = Prefs.games(ctx)
            .filter { Device.isInstalled(ctx, it) }
            .map { it to Device.labelOf(ctx, it) }
            .sortedBy { it.second.lowercase() }

        b.gameEmpty.visibility = if (installed.isEmpty()) View.VISIBLE else View.GONE
        installed.forEach { (pkg, label) ->
            val row = layoutInflater.inflate(R.layout.item_game, b.gameList, false)
            row.findViewById<TextView>(R.id.gameName).text = label
            row.findViewById<MaterialButton>(R.id.gamePlay).setOnClickListener {
                (requireActivity() as MainActivity).startBooster(pkg)
            }
            b.gameList.addView(row)
        }
    }
}
