package com.askaa.booster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.askaa.booster.databinding.ActivityCleanupBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.util.concurrent.Executors

class CleanupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCleanupBinding
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var junk: List<DocumentFile> = emptyList()

    private val pickFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                scanFolder(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCleanupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.ownCacheValue.text = Formatter.formatFileSize(this, dirSize(cacheDir))
        binding.btnCacheList.setOnClickListener { loadAppCaches() }
        binding.btnOwnCache.setOnClickListener { clearOwnCache() }
        binding.btnPickFolder.setOnClickListener { pickFolder.launch(null) }
        binding.btnCleanJunk.setOnClickListener { confirmClean() }
        binding.btnCleanJunk.isEnabled = false
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun dirSize(f: File): Long {
        if (!f.exists()) return 0L
        if (!f.isDirectory) return f.length()
        return f.listFiles()?.sumOf { dirSize(it) } ?: 0L
    }

    private fun clearOwnCache() {
        worker.execute {
            cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            val size = Formatter.formatFileSize(this, dirSize(cacheDir))
            main.post {
                binding.ownCacheValue.text = size
                Toast.makeText(this, "Cache booster dibersihkan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadAppCaches() {
        binding.cacheValue.text = "menghitung..."
        worker.execute {
            val rows = Device.launchableApps(this)
                .map { it.label to Device.cacheBytes(this, it.pkg) }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .take(15)

            val listText = if (rows.isEmpty()) {
                "tidak ada data cache yang bisa dibaca. Pastikan izin pemakaian data sudah aktif."
            } else {
                rows.joinToString("\n") { "${it.first}  ${Formatter.formatFileSize(this, it.second)}" }
            }
            main.post {
                binding.cacheValue.text = listText + "\n\nUntuk menghapus cache app, buka info app lalu pilih hapus cache."
            }
        }
    }

    private fun scanFolder(uri: Uri) {
        binding.junkValue.text = "memindai..."
        worker.execute {
            val dir = DocumentFile.fromTreeUri(this, uri)
            val found = dir?.listFiles()?.filter { f ->
                f.isFile && (f.name?.endsWith(".apk", ignoreCase = true) == true || f.length() == 0L)
            } ?: emptyList()
            junk = found

            val text = if (found.isEmpty()) {
                "tidak ada file sampah di folder ini"
            } else {
                val total = found.sumOf { it.length() }
                val names = found.take(20).joinToString("\n") { it.name ?: "tanpa nama" }
                "${found.size} file, ${Formatter.formatFileSize(this, total)}\n$names"
            }
            main.post {
                binding.junkValue.text = text
                binding.btnCleanJunk.isEnabled = found.isNotEmpty()
            }
        }
    }

    private fun confirmClean() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.clean_confirm_title)
            .setMessage(R.string.clean_confirm_desc)
            .setPositiveButton("Hapus") { _, _ -> deleteJunk() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteJunk() {
        val targets = junk
        worker.execute {
            val deleted = targets.count { it.delete() }
            junk = emptyList()
            main.post {
                binding.junkValue.text = "$deleted file dihapus"
                binding.btnCleanJunk.isEnabled = false
            }
        }
    }
}
