package com.askaa.booster

import android.os.Bundle
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.askaa.booster.databinding.ActivityPickGameBinding

class PickGameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPickGameBinding
    private val selected = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPickGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selected.addAll(Prefs.games(this))
        val pad = (12 * resources.displayMetrics.density).toInt()

        Device.launchableApps(this).forEach { app ->
            val box = CheckBox(this).apply {
                text = app.label
                textSize = 15f
                setTextColor(ContextCompat.getColor(this@PickGameActivity, R.color.ivory))
                setPadding(pad, pad, pad, pad)
                isChecked = app.pkg in selected
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(app.pkg) else selected.remove(app.pkg)
                }
            }
            binding.appList.addView(box)
        }

        binding.saveButton.setOnClickListener {
            Prefs.saveGames(this, selected)
            Toast.makeText(this, "Daftar game tersimpan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
