package com.askaa.booster

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.askaa.booster.databinding.ActivitySettingsBinding
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bind(binding.switchDnd, Option.DND)
        bind(binding.switchTimeout, Option.TIMEOUT)
        bind(binding.switchKillBg, Option.KILL_BG)
        bind(binding.switchLock, Option.LOCK)

        if (!Device.isDeviceSecure(this)) {
            binding.switchLock.isChecked = false
            binding.switchLock.isEnabled = false
            binding.lockNote.text = getString(R.string.lock_none)
        }
    }

    private fun bind(sw: MaterialSwitch, option: Option) {
        sw.isChecked = Prefs.isOn(this, option)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setOn(this, option, on) }
    }
}
