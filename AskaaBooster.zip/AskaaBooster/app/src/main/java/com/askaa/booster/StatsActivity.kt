package com.askaa.booster

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.askaa.booster.databinding.ActivityStatsBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class StatsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStatsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStatsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val history = Prefs.history(this)
        val days = lastDays(history)
        drawChart(days)

        val weekTotal = days.sumOf { it.second }
        binding.statTotal.text = "$weekTotal menit dalam 7 hari"

        val topGame = history
            .groupBy { it.label }
            .mapValues { entry -> entry.value.sumOf { it.minutes } }
            .maxByOrNull { it.value }
        binding.statTop.text = if (topGame == null) {
            "game paling sering: belum ada"
        } else {
            "game paling sering: ${topGame.key} (${topGame.value} menit)"
        }
        binding.statSessions.text = "${history.size} sesi tercatat"

        if (history.isEmpty()) binding.statTotal.text = getString(R.string.stats_empty)
    }

    /** Total menit main per hari untuk 7 hari terakhir, dari yang paling lama. */
    private fun lastDays(history: List<Session>): List<Pair<String, Long>> {
        val fmt = SimpleDateFormat("EEE", Locale("id", "ID"))
        return (6 downTo 0).map { back ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -back)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val start = cal.timeInMillis
            val end = start + 86_400_000L
            val minutes = history.filter { it.start >= start && it.start < end }.sumOf { it.minutes }
            fmt.format(Date(start)) to minutes
        }
    }

    private fun drawChart(days: List<Pair<String, Long>>) {
        val max = (days.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
        val muted = ContextCompat.getColor(this, R.color.muted)
        binding.chartBars.removeAllViews()

        days.forEach { (label, minutes) ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            }

            val barHeight = dp(4 + (minutes * 130 / max).toInt())
            val bar = View(this).apply { setBackgroundResource(R.drawable.bg_badge) }
            column.addView(bar, LinearLayout.LayoutParams(dp(18), barHeight))

            val text = TextView(this).apply {
                this.text = label
                textSize = 11f
                setTextColor(muted)
                gravity = Gravity.CENTER
            }
            val textParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
            column.addView(text, textParams)

            binding.chartBars.addView(column)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
