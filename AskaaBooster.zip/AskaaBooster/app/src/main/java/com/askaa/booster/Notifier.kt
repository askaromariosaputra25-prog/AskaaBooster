package com.askaa.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Semua notifikasi booster ada di sini supaya gaya dan warnanya konsisten. */
object Notifier {

    const val CH_STATUS = "booster_status"
    const val CH_EVENT = "booster_event"
    const val ID_STATUS = 1

    private fun nm(c: Context) = c.getSystemService(NotificationManager::class.java)

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun createChannels(c: Context) {
        nm(c).createNotificationChannel(
            NotificationChannel(CH_STATUS, "Status booster", NotificationManager.IMPORTANCE_LOW)
        )
        nm(c).createNotificationChannel(
            NotificationChannel(CH_EVENT, "Kejadian booster", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    fun status(c: Context, title: String, body: String, game: String?): Notification {
        val openApp = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), flags())
        val stop = PendingIntent.getService(
            c, 1,
            Intent(c, BoostService::class.java).setAction(BoostService.ACTION_STOP),
            flags()
        )

        val builder = NotificationCompat.Builder(c, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setColor(ContextCompat.getColor(c, R.color.rose))
            .setContentTitle(title)
            .setContentText(body.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Matikan", stop)

        if (game != null) {
            c.packageManager.getLaunchIntentForPackage(game)?.let { launch ->
                builder.addAction(0, "Buka game", PendingIntent.getActivity(c, 2, launch, flags()))
            }
        }
        return builder.build()
    }

    fun event(c: Context, title: String, body: String) {
        val openApp = PendingIntent.getActivity(c, 3, Intent(c, MainActivity::class.java), flags())
        val notif = NotificationCompat.Builder(c, CH_EVENT)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setColor(ContextCompat.getColor(c, R.color.rose))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        nm(c).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notif)
    }
}
