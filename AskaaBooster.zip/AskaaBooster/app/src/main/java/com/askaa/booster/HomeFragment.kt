package com.askaa.booster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.askaa.booster.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val main = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            refresh()
            main.postDelayed(this, 2000L)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val act = requireActivity() as MainActivity

        b.btnToggle.setOnClickListener {
            if (Prefs.isBoosted(requireContext())) act.stopBooster() else act.startBooster()
        }
        b.timerOff.setOnClickListener { setTimer(0) }
        b.timer30.setOnClickListener { setTimer(30) }
        b.timer60.setOnClickListener { setTimer(60) }
        b.timer120.setOnClickListener { setTimer(120) }

        b.btnUsage.setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        b.btnDnd.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        b.btnWrite.setOnClickListener {
            val uri = Uri.parse("package:${requireContext().packageName}")
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, uri))
        }
    }

    override fun onResume() {
        super.onResume()
        main.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        main.removeCallbacks(refresher)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private fun setTimer(minutes: Int) {
        Prefs.setTimerMinutes(requireContext(), minutes)
        refresh()
    }

    private fun refresh() {
        val ctx = context ?: return
        val boosted = Prefs.isBoosted(ctx)

        b.statusTitle.text = if (boosted) "booster aktif" else "booster siap"
        b.btnToggle.text = if (boosted) "matikan booster" else "mulai booster"
        b.statusValue.text = Prefs.status(ctx)
        b.gameValue.text = Prefs.currentGame(ctx)?.let { Device.labelOf(ctx, it) } ?: "belum ada game"
        b.tempValue.text = String.format("%.1f °C", Device.batteryTempC(ctx))

        val timer = Prefs.timerMinutes(ctx)
        b.timerValue.text = if (timer > 0) "$timer menit" else "tanpa timer"

        val missing = buildList {
            if (!Device.hasUsageAccess(ctx)) add("pemakaian data")
            if (!Device.hasDndAccess(ctx)) add("jangan ganggu")
            if (!Device.canWriteSettings(ctx)) add("ubah layar")
        }
        b.permValue.text = if (missing.isEmpty()) "semua izin sudah siap" else "belum diizinkan: ${missing.joinToString(", ")}"
    }
}
