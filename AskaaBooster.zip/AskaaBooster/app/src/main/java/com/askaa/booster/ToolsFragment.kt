package com.askaa.booster

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.askaa.booster.databinding.FragmentToolsBinding

class ToolsFragment : Fragment() {

    private var _b: FragmentToolsBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentToolsBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.cardNetwork.setOnClickListener { open(NetworkActivity::class.java) }
        b.cardCleanup.setOnClickListener { open(CleanupActivity::class.java) }
        b.cardDisplay.setOnClickListener { open(DisplayActivity::class.java) }
        b.cardGuide.setOnClickListener { open(GuideActivity::class.java) }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private fun open(target: Class<*>) {
        startActivity(Intent(requireContext(), target))
    }
}
