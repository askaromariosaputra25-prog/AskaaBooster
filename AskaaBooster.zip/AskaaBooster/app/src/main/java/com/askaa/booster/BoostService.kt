package com.askaa.booster

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Settings
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Berjalan di latar belakang dan memantau app yang sedang dibuka.
 * - Game terbuka: mode jangan ganggu dan waktu layar dinaikkan (kalau diizinkan dan dinyalakan).
 * - Game ditutup: setting awal dikembalikan dari snapshot.
 * - Kalau app sempat mati di tengah sesi, setting dikembalikan di tick berikutnya.
 */
class BoostService : Service() {

    private val lock = Any()
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var started = false
    private var foreground: String? = null
    private var lastQuery = 0L
    private var lastWarnAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
        lastQuery = System.currentTimeMillis() - 60_000L
        startForeground(Notifier.ID_STATUS, Notifier.status(this, "Askaa Booster", "memulai...", null))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            executor.scheduleWithFixedDelay({ safeTick() }, 0L, 3L, TimeUnit.SECONDS)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        executor.shutdown()
        Thread {
            synchronized(lock) {
                if (Prefs.isBoosted(this) || Prefs.hasSnapshot(this)) restore("booster dimatikan")
            }
        }.start()
        super.onDestroy()
    }

    private fun safeTick() {
        try {
            synchronized(lock) { tick() }
        } catch (e: Throwable) {
            Prefs.saveStatus(this, "terjadi error: ${e.message ?: "tidak diketahui"}")
        }
    }

    private fun tick() {
        val now = System.currentTimeMillis()

        if (!Device.hasUsageAccess(this)) {
            if (Prefs.isBoosted(this) || Prefs.hasSnapshot(this)) restore("izin pemakaian data dicabut")
            Prefs.saveStatus(this, "izin pemakaian data belum diberikan")
            refreshNotification()
            return
        }

        updateForeground(now)
        val fg = foreground
        val game = if (fg != null && fg in Prefs.games(this)) fg else null
        val temp = Device.batteryTempC(this)

        if (temp >= TEMP_WARN && now - lastWarnAt > WARN_COOLDOWN_MS) {
            lastWarnAt = now
            Notifier.event(
                this,
                "HP mulai panas",
                "Suhu baterai ${"%.1f".format(temp)} °C. Istirahatkan HP sebentar."
            )
        }

        val boosted = Prefs.isBoosted(this)
        when {
            !boosted && Prefs.hasSnapshot(this) -> restore("setting dikembalikan")
            boosted && game == null -> restore("game ditutup, setting dikembalikan")
            boosted -> Unit
            game != null -> boost(game)
            else -> Prefs.saveStatus(this, "menunggu game")
        }
        refreshNotification()
    }

    /** Membaca event buka dan tutup app sejak pengecekan terakhir. */
    private fun updateForeground(now: Long) {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(lastQuery, now)
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            when (event.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> foreground = event.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (event.packageName == foreground) foreground = null
                }
            }
        }
        lastQuery = now
    }

    private fun boost(game: String) {
        val nm = getSystemService(NotificationManager::class.java)
        val dndFilter = if (Device.hasDndAccess(this)) nm.currentInterruptionFilter else -1
        val timeout = if (Device.canWriteSettings(this)) {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, -1)
        } else {
            -1
        }

        // Catat setting awal dulu, baru ubah. Kalau app mati di tengah, sesi bisa dikembalikan.
        Prefs.saveSnapshot(this, dndFilter, timeout)
        Prefs.setSession(this, game, System.currentTimeMillis())
        Prefs.setBoosted(this, true)

        try {
            if (Prefs.isOn(this, Option.DND) && dndFilter != -1) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            }
            if (Prefs.isOn(this, Option.TIMEOUT) && timeout != -1) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, LONG_TIMEOUT_MS)
            }
            if (Prefs.isOn(this, Option.KILL_BG)) killBackground(game)
        } catch (e: Exception) {
            // Sebagian setting gagal diterapkan. Tetap lanjut, dan restore akan mencoba mengembalikannya.
        }

        val label = Device.labelOf(this, game)
        Prefs.saveStatus(this, "aktif untuk $label")
        Notifier.event(this, "Booster aktif", "$label siap. Setting kembali saat kamu keluar dari game.")
    }

    /** Mengembalikan setting dari snapshot. Snapshot dihapus hanya kalau berhasil. */
    private fun restore(reason: String) {
        val wasBoosted = Prefs.isBoosted(this)
        val startedAt = Prefs.sessionStart(this)
        val nm = getSystemService(NotificationManager::class.java)
        val dnd = Prefs.snapDnd(this)
        val timeout = Prefs.snapTimeout(this)

        val ok = try {
            if (dnd != -1 && Device.hasDndAccess(this)) nm.setInterruptionFilter(dnd)
            if (timeout != -1 && Device.canWriteSettings(this)) {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, timeout)
            }
            true
        } catch (e: Exception) {
            false
        }

        if (ok) Prefs.clearSnapshot(this)
        Prefs.setBoosted(this, false)
        Prefs.setSession(this, null, 0L)
        Prefs.saveStatus(this, if (ok) reason else "gagal mengembalikan setting, akan dicoba lagi")

        if (wasBoosted) {
            val minutes = if (startedAt > 0) (System.currentTimeMillis() - startedAt) / 60_000 else 0
            Notifier.event(
                this,
                "Setting dikembalikan",
                "Sesi main $minutes menit selesai. Jangan ganggu dan layar kembali seperti semula."
            )
        }
    }

    private fun killBackground(game: String) {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        Device.launchableApps(this).forEach { app ->
            if (app.pkg != game) am.killBackgroundProcesses(app.pkg)
        }
    }

    private fun refreshNotification() {
        val boosted = Prefs.isBoosted(this)
        val game = if (boosted) Prefs.currentGame(this) else null
        val title = if (game != null) "Booster aktif · ${Device.labelOf(this, game)}" else "Askaa Booster"
        val minutes = if (boosted) (System.currentTimeMillis() - Prefs.sessionStart(this)) / 60_000 else 0
        val temp = Device.batteryTempC(this)
        val extra = if (boosted) "\nsesi $minutes menit" else ""
        val body = "${Prefs.status(this)}\nsuhu baterai ${"%.1f".format(temp)} °C$extra"

        getSystemService(NotificationManager::class.java)
            .notify(Notifier.ID_STATUS, Notifier.status(this, title, body, game))
    }

    companion object {
        const val ACTION_STOP = "com.askaa.booster.STOP"
        private const val TEMP_WARN = 42.0
        private const val WARN_COOLDOWN_MS = 10 * 60_000L
        private const val LONG_TIMEOUT_MS = 10 * 60_000
    }
}
