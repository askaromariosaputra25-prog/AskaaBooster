package com.askaa.booster

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.askaa.booster.databinding.ActivityGameProfileBinding

class GameProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pkg = intent.getStringExtra("pkg")
        if (pkg == null) {
            finish()
            return
        }

        binding.profTitle.text = Device.labelOf(this, pkg)
        val p = Prefs.profile(this, pkg)
        binding.switchDnd.isChecked = p.dnd
        binding.switchTimeout.isChecked = p.timeout
        binding.switchKillBg.isChecked = p.killBg
        binding.hzGroup.check(
            when (p.hz) {
                30 -> R.id.hz30
                60 -> R.id.hz60
                120 -> R.id.hz120
                else -> R.id.hzOff
            }
        )

        binding.btnSaveProfile.setOnClickListener {
            val hz = when (binding.hzGroup.checkedRadioButtonId) {
                R.id.hz30 -> 30
                R.id.hz60 -> 60
                R.id.hz120 -> 120
                else -> 0
            }
            Prefs.saveProfile(
                this,
                pkg,
                GameProfile(
                    binding.switchDnd.isChecked,
                    binding.switchTimeout.isChecked,
                    binding.switchKillBg.isChecked,
                    hz
                )
            )
            Toast.makeText(this, "Profil disimpan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
