package com.askaa.booster

import android.os.Environment
import android.os.StatFs

object StorageInfo {

    /** Sisa penyimpanan internal dalam byte. */
    fun freeBytes(): Long {
        return try {
            StatFs(Environment.getDataDirectory().path).availableBytes
        } catch (e: Exception) {
            Long.MAX_VALUE
        }
    }
}
