package com.askaa.booster

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.askaa.booster.databinding.FragmentMoreBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MoreFragment : Fragment() {

    private var _b: FragmentMoreBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentMoreBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()

        bindSwitch(b.switchDnd, Option.DND)
        bindSwitch(b.switchTimeout, Option.TIMEOUT)
        bindSwitch(b.switchKillBg, Option.KILL_BG)
        bindSwitch(b.switchLock, Option.LOCK)
        if (!Device.isDeviceSecure(ctx)) {
            b.switchLock.isChecked = false
            b.switchLock.isEnabled = false
            b.lockNote.text = getString(R.string.lock_none)
        }

        b.btnClearHistory.setOnClickListener {
            Prefs.clearHistory(ctx)
            renderHistory()
        }
        b.btnGuide.setOnClickListener { startActivity(Intent(ctx, GuideActivity::class.java)) }
        b.btnAbout.setOnClickListener { showAbout() }
    }

    override fun onResume() {
        super.onResume()
        renderHistory()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    private fun bindSwitch(sw: MaterialSwitch, option: Option) {
        val ctx = requireContext()
        sw.isChecked = Prefs.isOn(ctx, option)
        sw.setOnCheckedChangeListener { _, on -> Prefs.setOn(ctx, option, on) }
    }

    private fun renderHistory() {
        val ctx = context ?: return
        b.historyList.removeAllViews()
        val items = Prefs.history(ctx)
        b.historyEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        val fmt = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID"))
        items.forEach { s ->
            val row = layoutInflater.inflate(R.layout.item_session, b.historyList, false)
            row.findViewById<TextView>(R.id.sessionName).text = s.label
            row.findViewById<TextView>(R.id.sessionDetail).text =
                "${fmt.format(Date(s.start))} · ${s.minutes} menit · suhu tertinggi ${"%.1f".format(s.maxTemp)} °C"
            b.historyList.addView(row)
        }
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.about_title)
            .setMessage(R.string.about_msg)
            .setPositiveButton("Oke", null)
            .show()
    }
}
