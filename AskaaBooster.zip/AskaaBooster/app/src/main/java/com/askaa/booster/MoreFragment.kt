package com.askaa.booster

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.askaa.booster.databinding.FragmentMoreBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MoreFragment : Fragment() {

    private var _b: FragmentMoreBinding? = null
    private val b get() = _b!!

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) exportTo(uri)
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importFrom(uri)
        }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentMoreBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()

        b.switchDnd.setOnCheckedChangeListener { _, on -> Prefs.setOn(ctx, Option.DND, on) }
        b.switchTimeout.setOnCheckedChangeListener { _, on -> Prefs.setOn(ctx, Option.TIMEOUT, on) }
        b.switchKillBg.setOnCheckedChangeListener { _, on -> Prefs.setOn(ctx, Option.KILL_BG, on) }
        b.switchLock.setOnCheckedChangeListener { _, on -> Prefs.setOn(ctx, Option.LOCK, on) }

        b.restGroup.setOnCheckedChangeListener { _, id ->
            val minutes = when (id) {
                R.id.rest45 -> 45
                R.id.rest60 -> 60
                else -> 0
            }
            Prefs.setRestEvery(ctx, minutes)
        }

        b.btnClearHistory.setOnClickListener {
            Prefs.clearHistory(ctx)
            renderHistory()
        }
        b.btnStats.setOnClickListener { startActivity(Intent(ctx, StatsActivity::class.java)) }
        b.btnExport.setOnClickListener { exportLauncher.launch("askaa-booster-backup.json") }
        b.btnImport.setOnClickListener {
            importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
        }
        b.btnGuide.setOnClickListener { startActivity(Intent(ctx, GuideActivity::class.java)) }
        b.btnAbout.setOnClickListener { showAbout() }

        if (!Device.isDeviceSecure(ctx)) {
            b.switchLock.isChecked = false
            b.switchLock.isEnabled = false
            b.lockNote.text = getString(R.string.lock_none)
        }
        refreshControls()
    }

    override fun onResume() {
        super.onResume()
        renderHistory()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _b = null
    }

    /** Menyamakan tampilan pengaturan dengan data yang tersimpan. */
    private fun refreshControls() {
        val ctx = context ?: return
        b.switchDnd.isChecked = Prefs.isOn(ctx, Option.DND)
        b.switchTimeout.isChecked = Prefs.isOn(ctx, Option.TIMEOUT)
        b.switchKillBg.isChecked = Prefs.isOn(ctx, Option.KILL_BG)
        b.switchLock.isChecked = Prefs.isOn(ctx, Option.LOCK) && Device.isDeviceSecure(ctx)
        when (Prefs.restEvery(ctx)) {
            45 -> b.rest45.isChecked = true
            60 -> b.rest60.isChecked = true
            else -> b.rest0.isChecked = true
        }
    }

    private fun renderHistory() {
        val ctx = context ?: return
        b.historyList.removeAllViews()
        val items = Prefs.history(ctx)
        b.historyEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

        val fmt = SimpleDateFormat("dd MMM, HH:mm", Locale("id", "ID"))
        items.forEach { s ->
            val row = layoutInflater.inflate(R.layout.item_session, b.historyList, false)
            row.findViewById<TextView>(R.id.sessionName).text = s.label
            row.findViewById<TextView>(R.id.sessionDetail).text =
                "${fmt.format(Date(s.start))} · ${s.minutes} menit · suhu tertinggi ${"%.1f".format(s.maxTemp)} °C"
            b.historyList.addView(row)
        }
    }

    private fun exportTo(uri: Uri) {
        val ctx = requireContext()
        val ok = try {
            val bytes = Prefs.exportAll(ctx).toString(2).toByteArray(Charsets.UTF_8)
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            true
        } catch (e: Exception) {
            false
        }
        Toast.makeText(ctx, getString(if (ok) R.string.backup_ok else R.string.backup_fail), Toast.LENGTH_SHORT).show()
    }

    private fun importFrom(uri: Uri) {
        val ctx = requireContext()
        val parsed: JSONObject? = try {
            val raw = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            val o = JSONObject(raw)
            if (o.optString("app") == "askaa_booster") o else null
        } catch (e: Exception) {
            null
        }

        if (parsed == null) {
            Toast.makeText(ctx, getString(R.string.import_fail), Toast.LENGTH_SHORT).show()
            return
        }
        Prefs.importAll(ctx, parsed)
        refreshControls()
        renderHistory()
        Toast.makeText(ctx, getString(R.string.import_ok), Toast.LENGTH_SHORT).show()
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.about_title)
            .setMessage(R.string.about_msg)
            .setPositiveButton("Oke", null)
            .show()
    }
}
