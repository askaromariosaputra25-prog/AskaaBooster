package com.askaa.booster

import android.content.Context

/** Pilihan yang bisa dinyalakan atau dimatikan di menu pengaturan. */
enum class Option(val key: String, val def: Boolean) {
    DND("opt_dnd", true),
    TIMEOUT("opt_timeout", true),
    KILL_BG("opt_killbg", false),
    LOCK("opt_lock", true)
}

object Prefs {

    private const val FILE = "askaa_booster"
    private const val KEY_GAMES = "games"
    private const val KEY_BOOSTED = "boosted"
    private const val KEY_STATUS = "status"
    private const val KEY_GAME = "current_game"
    private const val KEY_SESSION = "session_start"
    private const val KEY_SNAP_DND = "snap_dnd"
    private const val KEY_SNAP_TIMEOUT = "snap_timeout"

    /** Daftar awal game. Bisa diubah lewat menu pilih game. */
    val DEFAULT_GAMES = setOf(
        "com.mobile.legends",
        "com.miHoYo.GenshinImpact",
        "com.tencent.ig",
        "com.dts.freefireth",
        "com.dts.freefiremax"
    )

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun games(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_GAMES, null)?.toSet() ?: DEFAULT_GAMES

    fun saveGames(context: Context, list: Collection<String>) {
        prefs(context).edit().putStringSet(KEY_GAMES, list.toSet()).apply()
    }

    fun isOn(context: Context, option: Option): Boolean =
        prefs(context).getBoolean(option.key, option.def)

    fun setOn(context: Context, option: Option, value: Boolean) {
        prefs(context).edit().putBoolean(option.key, value).apply()
    }

    fun isBoosted(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BOOSTED, false)

    fun setBoosted(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_BOOSTED, value).apply()
    }

    /** Snapshot setting awal sebelum booster mengubah apa pun. -1 berarti tidak dicatat. */
    fun saveSnapshot(context: Context, dnd: Int, timeout: Int) {
        prefs(context).edit()
            .putInt(KEY_SNAP_DND, dnd)
            .putInt(KEY_SNAP_TIMEOUT, timeout)
            .apply()
    }

    fun hasSnapshot(context: Context): Boolean =
        prefs(context).contains(KEY_SNAP_DND)

    fun snapDnd(context: Context): Int = prefs(context).getInt(KEY_SNAP_DND, -1)

    fun snapTimeout(context: Context): Int = prefs(context).getInt(KEY_SNAP_TIMEOUT, -1)

    fun clearSnapshot(context: Context) {
        prefs(context).edit().remove(KEY_SNAP_DND).remove(KEY_SNAP_TIMEOUT).apply()
    }

    fun currentGame(context: Context): String? =
        prefs(context).getString(KEY_GAME, null)

    fun sessionStart(context: Context): Long =
        prefs(context).getLong(KEY_SESSION, 0L)

    fun setSession(context: Context, game: String?, start: Long) {
        prefs(context).edit().putString(KEY_GAME, game).putLong(KEY_SESSION, start).apply()
    }

    fun saveStatus(context: Context, text: String) {
        prefs(context).edit().putString(KEY_STATUS, text).apply()
    }

    fun status(context: Context): String =
        prefs(context).getString(KEY_STATUS, null) ?: "belum aktif"
}
