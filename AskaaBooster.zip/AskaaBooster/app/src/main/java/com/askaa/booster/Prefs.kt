package com.askaa.booster

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Pilihan umum yang bisa dinyalakan atau dimatikan. */
enum class Option(val key: String, val def: Boolean) {
    DND("opt_dnd", true),
    TIMEOUT("opt_timeout", true),
    KILL_BG("opt_killbg", false),
    LOCK("opt_lock", true)
}

/** Satu sesi main yang sudah selesai. */
data class Session(
    val game: String,
    val label: String,
    val start: Long,
    val minutes: Long,
    val maxTemp: Double
)

/** Profil khusus satu game. */
data class GameProfile(
    val dnd: Boolean,
    val timeout: Boolean,
    val killBg: Boolean,
    val hz: Int
)

object Prefs {

    private const val FILE = "askaa_booster_v3"
    private const val KEY_GAMES = "games"
    private const val KEY_BOOSTED = "boosted"
    private const val KEY_STATUS = "status"
    private const val KEY_GAME = "current_game"
    private const val KEY_SESSION = "session_start"
    private const val KEY_MAX_TEMP = "max_temp"
    private const val KEY_SNAP_DND = "snap_dnd"
    private const val KEY_SNAP_TIMEOUT = "snap_timeout"
    private const val KEY_TIMER_MIN = "timer_minutes"
    private const val KEY_TIMER_END = "timer_end"
    private const val KEY_HISTORY = "history"
    private const val KEY_HZ_TARGET = "hz_target"
    private const val KEY_HZ_PEAK = "hz_snap_peak"
    private const val KEY_HZ_MIN = "hz_snap_min"
    private const val KEY_REST = "rest_every"
    private const val KEY_NEXT_REST = "next_rest"
    private const val PROFILE_PREFIX = "profile_"

    /** Daftar awal game. Bisa diubah lewat menu pilih game. */
    val DEFAULT_GAMES = setOf(
        "com.mobile.legends",
        "com.miHoYo.GenshinImpact",
        "com.tencent.ig",
        "com.dts.freefireth",
        "com.dts.freefiremax"
    )

    private fun prefs(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun games(c: Context): Set<String> =
        prefs(c).getStringSet(KEY_GAMES, null)?.toSet() ?: DEFAULT_GAMES

    fun saveGames(c: Context, list: Collection<String>) {
        prefs(c).edit().putStringSet(KEY_GAMES, list.toSet()).apply()
    }

    fun isOn(c: Context, o: Option): Boolean = prefs(c).getBoolean(o.key, o.def)

    fun setOn(c: Context, o: Option, v: Boolean) {
        prefs(c).edit().putBoolean(o.key, v).apply()
    }

    fun isBoosted(c: Context): Boolean = prefs(c).getBoolean(KEY_BOOSTED, false)

    fun setBoosted(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean(KEY_BOOSTED, v).apply()
    }

    fun saveSnapshot(c: Context, dnd: Int, timeout: Int) {
        prefs(c).edit().putInt(KEY_SNAP_DND, dnd).putInt(KEY_SNAP_TIMEOUT, timeout).apply()
    }

    fun hasSnapshot(c: Context): Boolean = prefs(c).contains(KEY_SNAP_DND)

    fun snapDnd(c: Context): Int = prefs(c).getInt(KEY_SNAP_DND, -1)

    fun snapTimeout(c: Context): Int = prefs(c).getInt(KEY_SNAP_TIMEOUT, -1)

    fun clearSnapshot(c: Context) {
        prefs(c).edit().remove(KEY_SNAP_DND).remove(KEY_SNAP_TIMEOUT).apply()
    }

    fun currentGame(c: Context): String? = prefs(c).getString(KEY_GAME, null)

    fun sessionStart(c: Context): Long = prefs(c).getLong(KEY_SESSION, 0L)

    fun setSession(c: Context, game: String?, start: Long) {
        prefs(c).edit()
            .putString(KEY_GAME, game)
            .putLong(KEY_SESSION, start)
            .putFloat(KEY_MAX_TEMP, 0f)
            .apply()
    }

    fun maxTemp(c: Context): Double = prefs(c).getFloat(KEY_MAX_TEMP, 0f).toDouble()

    fun updateMaxTemp(c: Context, t: Double) {
        if (t > maxTemp(c)) prefs(c).edit().putFloat(KEY_MAX_TEMP, t.toFloat()).apply()
    }

    fun timerMinutes(c: Context): Int = prefs(c).getInt(KEY_TIMER_MIN, 0)

    fun setTimerMinutes(c: Context, m: Int) {
        prefs(c).edit().putInt(KEY_TIMER_MIN, m).apply()
    }

    fun timerEnd(c: Context): Long = prefs(c).getLong(KEY_TIMER_END, 0L)

    fun setTimerEnd(c: Context, t: Long) {
        prefs(c).edit().putLong(KEY_TIMER_END, t).apply()
    }

    fun history(c: Context): List<Session> {
        val raw = prefs(c).getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Session(
                    o.getString("game"),
                    o.getString("label"),
                    o.getLong("start"),
                    o.getLong("minutes"),
                    o.getDouble("temp")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addSession(c: Context, s: Session) {
        val list = (listOf(s) + history(c)).take(200)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("game", it.game)
                    .put("label", it.label)
                    .put("start", it.start)
                    .put("minutes", it.minutes)
                    .put("temp", it.maxTemp)
            )
        }
        prefs(c).edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    fun clearHistory(c: Context) {
        prefs(c).edit().remove(KEY_HISTORY).apply()
    }

    fun hzTarget(c: Context): Int = prefs(c).getInt(KEY_HZ_TARGET, 0)

    fun setHzTarget(c: Context, hz: Int) {
        prefs(c).edit().putInt(KEY_HZ_TARGET, hz).apply()
    }

    fun hasHzSnap(c: Context): Boolean = prefs(c).contains(KEY_HZ_PEAK)

    fun saveHzSnap(c: Context, peak: String, min: String) {
        prefs(c).edit().putString(KEY_HZ_PEAK, peak).putString(KEY_HZ_MIN, min).apply()
    }

    fun hzSnap(c: Context): Pair<String, String> =
        Pair(
            prefs(c).getString(KEY_HZ_PEAK, "") ?: "",
            prefs(c).getString(KEY_HZ_MIN, "") ?: ""
        )

    fun clearHzSnap(c: Context) {
        prefs(c).edit().remove(KEY_HZ_PEAK).remove(KEY_HZ_MIN).apply()
    }

    fun saveStatus(c: Context, text: String) {
        prefs(c).edit().putString(KEY_STATUS, text).apply()
    }

    fun status(c: Context): String = prefs(c).getString(KEY_STATUS, null) ?: "belum aktif"

    /** Profil game. Kalau belum pernah diatur, pakai pengaturan umum. */
    fun profile(c: Context, pkg: String): GameProfile {
        val raw = prefs(c).getString(PROFILE_PREFIX + pkg, null)
        if (raw != null) {
            try {
                val o = JSONObject(raw)
                return GameProfile(
                    o.getBoolean("dnd"),
                    o.getBoolean("timeout"),
                    o.getBoolean("killBg"),
                    o.getInt("hz")
                )
            } catch (e: Exception) {
                // profil rusak, pakai pengaturan umum
            }
        }
        return GameProfile(
            isOn(c, Option.DND),
            isOn(c, Option.TIMEOUT),
            isOn(c, Option.KILL_BG),
            hzTarget(c)
        )
    }

    fun saveProfile(c: Context, pkg: String, p: GameProfile) {
        val o = JSONObject()
            .put("dnd", p.dnd)
            .put("timeout", p.timeout)
            .put("killBg", p.killBg)
            .put("hz", p.hz)
        prefs(c).edit().putString(PROFILE_PREFIX + pkg, o.toString()).apply()
    }

    /** Pengingat istirahat dalam menit. 0 berarti mati. */
    fun restEvery(c: Context): Int = prefs(c).getInt(KEY_REST, 0)

    fun setRestEvery(c: Context, m: Int) {
        prefs(c).edit().putInt(KEY_REST, m).apply()
    }

    fun nextRestAt(c: Context): Long = prefs(c).getLong(KEY_NEXT_REST, 0L)

    fun setNextRestAt(c: Context, t: Long) {
        prefs(c).edit().putLong(KEY_NEXT_REST, t).apply()
    }

    /** Semua pengaturan dalam satu objek JSON, untuk cadangan. */
    fun exportAll(c: Context): JSONObject {
        val o = JSONObject()
        o.put("app", "askaa_booster")
        o.put("games", JSONArray(games(c).toList()))
        o.put("dnd", isOn(c, Option.DND))
        o.put("timeout", isOn(c, Option.TIMEOUT))
        o.put("killBg", isOn(c, Option.KILL_BG))
        o.put("lock", isOn(c, Option.LOCK))
        o.put("hz", hzTarget(c))
        o.put("timer", timerMinutes(c))
        o.put("rest", restEvery(c))

        val profiles = JSONObject()
        prefs(c).all.forEach { (key, value) ->
            if (key.startsWith(PROFILE_PREFIX) && value is String) {
                profiles.put(key.removePrefix(PROFILE_PREFIX), value)
            }
        }
        o.put("profiles", profiles)
        return o
    }

    fun importAll(c: Context, o: JSONObject) {
        val arr = o.optJSONArray("games")
        if (arr != null && arr.length() > 0) {
            saveGames(c, (0 until arr.length()).map { arr.getString(it) })
        }
        setOn(c, Option.DND, o.optBoolean("dnd", true))
        setOn(c, Option.TIMEOUT, o.optBoolean("timeout", true))
        setOn(c, Option.KILL_BG, o.optBoolean("killBg", false))
        setOn(c, Option.LOCK, o.optBoolean("lock", true))
        setHzTarget(c, o.optInt("hz", 0))
        setTimerMinutes(c, o.optInt("timer", 0))
        setRestEvery(c, o.optInt("rest", 0))

        val profiles = o.optJSONObject("profiles")
        if (profiles != null) {
            val editor = prefs(c).edit()
            val keys = profiles.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                editor.putString(PROFILE_PREFIX + k, profiles.getString(k))
            }
            editor.apply()
        }
    }
}
