# Askaa Booster (tanpa root)

Booster untuk Android yang tidak butuh root. Saat game dari daftar terbuka, mode jangan ganggu dan waktu layar diatur. Saat game ditutup, setting awal dikembalikan.

## Fitur
- Pilih game dari app yang terpasang, lalu buka game langsung dari app
- Deteksi otomatis saat game dibuka dan ditutup
- Snapshot setting awal, dikembalikan saat game ditutup atau app mati di tengah sesi
- Notifikasi status dengan tombol Buka game dan Matikan
- Peringatan saat suhu baterai mulai panas
- Kunci app pakai sidik jari atau kunci layar HP

## Izin yang perlu diberikan manual
1. Akses penggunaan (untuk deteksi game)
2. Jangan ganggu (untuk mode jangan ganggu saat main)
3. Ubah pengaturan sistem (untuk waktu layar mati)
4. Notifikasi (Android 13 ke atas)

## Batasan
- Tidak menjamin FPS naik. Efeknya tergantung HP.
- Menutup app latar belakang hanya membantu sedikit, dan bisa membuat pesan terlambat masuk.

## Build dari HP
Gunakan repository `AskaaBooster` dan jalankan workflow Build APK seperti biasa.
