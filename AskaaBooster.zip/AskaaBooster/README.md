# Askaa Booster v4 (tanpa root)

Booster untuk Android tanpa root. Menu dibagi per tab: beranda, game, alat, dan lainnya.

## Fitur
- Beranda: status booster, mulai dan matikan, timer main 30, 60, atau 120 menit
- Game: pilih game, tekan main, dan atur profil khusus tiap game (jangan ganggu, layar, tutup app latar, Hz)
- Alat: cek jaringan (ping, tes speed, sinyal WiFi), bersih-bersih (cache per app dengan tombol info app, cache booster, file sampah di folder download), layar dan Hz, panduan
- Lainnya: riwayat sesi, statistik 7 hari, pengingat istirahat, cadangan pengaturan (ekspor dan impor), panduan, dan tentang app
- Widget di layar home dan tile di panel Quick Settings
- Shortcut di ikon app: tahan ikon untuk langsung main game favorit
- Kunci app pakai sidik jari atau kunci layar HP
- Peringatan penyimpanan hampir penuh sebelum main

## Izin
1. Akses penggunaan
2. Jangan ganggu
3. Ubah pengaturan sistem
4. Notifikasi (Android 13 ke atas)
5. Opsional untuk Hz: WRITE_SECURE_SETTINGS lewat ADB. Di HP tanpa PC bisa lewat Termux dengan Debugging nirkabel.

## Batasan
- Tidak menjamin FPS naik. FPS game diatur di dalam game.
- Hz dari app tidak dijamin berjalan di semua HP, terutama ColorOS.
- Booster tidak bisa menghapus cache app lain secara langsung.
