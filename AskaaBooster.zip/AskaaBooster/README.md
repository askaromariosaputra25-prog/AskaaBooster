# Askaa Booster v3 (tanpa root)

Booster untuk Android tanpa root. Menu dibagi per tab: beranda, game, alat, dan lainnya.

## Fitur
- Beranda: status booster, mulai dan matikan, timer main 30, 60, atau 120 menit
- Game: pilih game dari app terpasang, lalu tekan main
- Alat: cek jaringan (ping, tes speed, sinyal WiFi), bersih-bersih (cache per app, cache booster, file sampah di folder download), layar dan Hz, dan panduan
- Lainnya: riwayat sesi, pengaturan, panduan, dan tentang app
- Kunci app pakai sidik jari atau kunci layar HP

## Izin
1. Akses penggunaan
2. Jangan ganggu
3. Ubah pengaturan sistem
4. Notifikasi (Android 13 ke atas)
5. Opsional untuk Hz: WRITE_SECURE_SETTINGS lewat ADB, biasanya butuh PC

## Batasan
- Tidak menjamin FPS naik. FPS game diatur di dalam game.
- Hz dari app tidak dijamin berjalan di semua HP, terutama ColorOS.
- Booster tidak bisa menghapus cache app lain secara langsung.
